/// <reference types="vite/client" />

declare namespace JSX {
  interface IntrinsicElements {
    "dotlottie-player": unknown;
  }
}
